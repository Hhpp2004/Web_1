const nomes: string[] = ["Gustavo", "Fernando"];
nomes.push("Gustavo");
// Descomente a linha abaixo para testar
// nomes.push(3);

const vetorNumeros = [1, 2, 3];
vetorNumeros.push(4);
// Descomente a linha abaixo para testar
// vetorNumeros.push("abc");
let variavel1: number = vetorNumeros[0];

let tupla1: [number, boolean, string];
tupla1 = [5, false, 'abc'];
// Descomente a linha abaixo para testar
// tupla1 = [false, 'abc', 5];

const grafico1: [x: number, y: number] = [10, 20];
grafico1[0] = 5;
grafico1[1] = 15;

const grafico2: [number, number] = [20, 10];
let [x, y] = grafico2;
console.log("X da desestruturação: " + x);
console.log("Y da desestruturação: " + y);

const carro: { modelo: string, avaliacao?: number } =
{
  modelo: "Corolla"
};
carro.avaliacao = 9;
carro.modelo = "Onix";
// Descomente a linha abaixo para testar
// carro.modelo = 2;

const mapaNomeIdade: { [index: string]: number } =
{
  Gustavo: 51
};
mapaNomeIdade.Fernando = 53;
// Descomente a linha abaixo para testar
// mapaNomeIdade.Aline = "Dezenove";
console.log(mapaNomeIdade);
console.log(mapaNomeIdade.Gustavo);
console.log(mapaNomeIdade.Fernando);