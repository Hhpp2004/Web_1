class Pessoa {
  public constructor(private readonly nome: string) {
  }
  public pegaNome(): string {
    return this.nome;
  }
  // Descomente as linhas abaixo para testar
  // public mudaNome(nome: string): void {
  //   this.nome = nome;
  // }
}
const pessoa = new Pessoa("Gustavo");
console.log(pessoa.pegaNome());
// Descomente a linha abaixo para testar
// console.log(pessoa.nome);

////////////////////////////////////////////////////////////////////
// Herança - interface, estender, sobrepor e classe abstrata
////////////////////////////////////////////////////////////////////

interface Forma { pegaArea: () => number; }
abstract class Poligono {
  public abstract pegaArea(): number;
  public paraString(): string { return `Poligono[area=${this.pegaArea()}]`; }
}
class Retangulo1 extends Poligono implements Forma {
  public constructor(protected readonly larguraForma: number, protected readonly alturaForma: number) {
    super();
  }
  public pegaArea(): number {
    return this.larguraForma * this.alturaForma;
  }
}
class Quadrado extends Retangulo1 {
  public constructor(larguraForma: number) {
    super(larguraForma, larguraForma);
  }
  public override paraString(): string {
    return `Quadrado[largura=${this.larguraForma}]`;
  }
}
const meuRetangulo = new Retangulo1(10, 20);
console.log(meuRetangulo.pegaArea());
console.log(meuRetangulo.paraString());
const meuQuadrado = new Quadrado(20);
console.log(meuQuadrado.pegaArea());
console.log(meuQuadrado.paraString());