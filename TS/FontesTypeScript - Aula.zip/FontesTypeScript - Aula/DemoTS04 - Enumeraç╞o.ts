enum pontosCardeais {
    Norte = 1,
    Leste,
    Sul,
    Oeste
}
let currentDirection = pontosCardeais.Norte;
console.log(currentDirection);
currentDirection = 2;
console.log(currentDirection);
// Descomente a linha abaixo para testar
// currentDirection = "Norte";

enum codigoEstado {
    naoEncontrado = 404,
    Sucesso = 200,
}
console.log(codigoEstado.naoEncontrado);
console.log(codigoEstado.Sucesso);

enum pontosCardeais2 {
    Norte = "Norte",
    Leste = "Leste",
    Sul = "Sul",
    Oeste = "Oeste"
};
console.log(pontosCardeais2.Norte);
console.log(pontosCardeais2.Oeste);
