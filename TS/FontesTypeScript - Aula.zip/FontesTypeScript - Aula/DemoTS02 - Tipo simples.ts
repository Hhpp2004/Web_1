let nome1: string = "Gustavo";
let nome2 = "Gustavo";
let idade: number = 0;
let brasileiro: boolean = true;

// Descomentar para testar erro
// nome1 = 33;
// nome2 = 33;
// idade = "abc";
// brasileiro = 0;

let teste: any = true;
teste = "string";
teste = 123;
teste = false;
