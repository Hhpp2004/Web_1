type AnoCarro = number
type ModeloCarro = string
type Carro = {
  ano: AnoCarro,
  modelo: ModeloCarro
}
const anoCarro: AnoCarro = 2024
const modeloCarro: ModeloCarro = "Corolla"
const carro1: Carro = {
  ano: anoCarro,
  modelo: modeloCarro
};
console.log(carro1);

interface Retangulo {
  altura: number,
  largura: number
}
const retangulo: Retangulo = {
  altura: 20,
  largura: 10
};
console.log(retangulo);

interface RetanguloColorido extends Retangulo {
  cor: string
}
const retanguloColorido: RetanguloColorido = {
  altura: 20,
  largura: 10,
  cor: "vermelho"
};
console.log(retanguloColorido);