function criaPar<S, T>(v1: S, v2: T): [S, T] {
    return [v1, v2];
}
console.log(criaPar<string, number>('Gustavo', 51));
console.log(criaPar<string, string>('Gustavo', 'Celma'));