interface Crianca {
  nome: string;
  idade: number;
}
function imprimeCrianca(crianca: Crianca, campo: keyof Crianca) {
  console.log(`Imprimindo criança.....: ${campo}: "${crianca[campo]}"`);
}
let crianca = {
  nome: "Pedrinho",
  idade: 10
};
imprimeCrianca(crianca, "nome");
imprimeCrianca(crianca, "idade");
// Descomente a linha abaixo para testar
// imprimeCrianca(crianca, "pai");