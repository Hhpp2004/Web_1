"use strict";
let meuAnimal1 = {};
meuAnimal1.nome = "Meg";
console.log(meuAnimal1);
let meuAnimal2 = {
    nome: 'Pepe',
    raca: 'Yorkshire',
    // Comente a linha abaixo para testar
    idade: 7
};
console.log(meuAnimal2);
const meuAnimal3 = {
    nome: 'Duda',
    // Descomente a linha abaixo para testar
    // idade: 7
};
console.log(meuAnimal3);
const meuAnimal4 = {
    nome: 'Bob',
    // Descomente as linhas abaixo para testar
    // raca: 'Yorkshire',
    // idade: 7
};
console.log(meuAnimal4);
const meuAnimal5 = {
    nome: 'Thor',
    raca: 'Rottweiler',
};
// Descomente a linha abaixo para testar
// meuAnimal5.nome = 'Gigante';
console.log(meuAnimal5);
let valor = true;
valor = 8;
// Descomente a linha abaixo para testar
// valor = "abc";
console.log(typeof valor);
const mapa = {
    'Alice': 21,
    'Bob': 25
};
console.log(mapa);
//# sourceMappingURL=DemoTS10%20-%20Tipos%20de%20utilit%C3%A1rios.js.map