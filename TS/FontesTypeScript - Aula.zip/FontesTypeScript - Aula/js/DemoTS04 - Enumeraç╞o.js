"use strict";
var pontosCardeais;
(function (pontosCardeais) {
    pontosCardeais[pontosCardeais["Norte"] = 1] = "Norte";
    pontosCardeais[pontosCardeais["Leste"] = 2] = "Leste";
    pontosCardeais[pontosCardeais["Sul"] = 3] = "Sul";
    pontosCardeais[pontosCardeais["Oeste"] = 4] = "Oeste";
})(pontosCardeais || (pontosCardeais = {}));
let currentDirection = pontosCardeais.Norte;
console.log(currentDirection);
currentDirection = 2;
console.log(currentDirection);
// Descomente a linha abaixo para testar
// currentDirection = "Norte";
var codigoEstado;
(function (codigoEstado) {
    codigoEstado[codigoEstado["naoEncontrado"] = 404] = "naoEncontrado";
    codigoEstado[codigoEstado["Sucesso"] = 200] = "Sucesso";
})(codigoEstado || (codigoEstado = {}));
console.log(codigoEstado.naoEncontrado);
console.log(codigoEstado.Sucesso);
var pontosCardeais2;
(function (pontosCardeais2) {
    pontosCardeais2["Norte"] = "Norte";
    pontosCardeais2["Leste"] = "Leste";
    pontosCardeais2["Sul"] = "Sul";
    pontosCardeais2["Oeste"] = "Oeste";
})(pontosCardeais2 || (pontosCardeais2 = {}));
;
console.log(pontosCardeais2.Norte);
console.log(pontosCardeais2.Oeste);
//# sourceMappingURL=DemoTS04%20-%20Enumera%C3%A7%C3%A3o.js.map