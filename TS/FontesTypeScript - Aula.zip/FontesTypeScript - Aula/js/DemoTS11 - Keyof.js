"use strict";
function imprimeCrianca(crianca, campo) {
    console.log(`Imprimindo criança.....: ${campo}: "${crianca[campo]}"`);
}
let crianca = {
    nome: "Pedrinho",
    idade: 10
};
imprimeCrianca(crianca, "nome");
imprimeCrianca(crianca, "idade");
// Descomente a linha abaixo para testar
// imprimeCrianca(crianca, "pai");
//# sourceMappingURL=DemoTS11%20-%20Keyof.js.map