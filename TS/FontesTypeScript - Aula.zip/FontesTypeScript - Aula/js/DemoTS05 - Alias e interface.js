"use strict";
const anoCarro = 2024;
const modeloCarro = "Corolla";
const carro1 = {
    ano: anoCarro,
    modelo: modeloCarro
};
console.log(carro1);
const retangulo = {
    altura: 20,
    largura: 10
};
console.log(retangulo);
const retanguloColorido = {
    altura: 20,
    largura: 10,
    cor: "vermelho"
};
console.log(retanguloColorido);
//# sourceMappingURL=DemoTS05%20-%20Alias%20e%20interface.js.map