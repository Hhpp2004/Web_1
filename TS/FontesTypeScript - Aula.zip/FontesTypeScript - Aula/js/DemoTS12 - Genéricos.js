"use strict";
function criaPar(v1, v2) {
    return [v1, v2];
}
console.log(criaPar('Gustavo', 51));
console.log(criaPar('Gustavo', 'Celma'));
//# sourceMappingURL=DemoTS12%20-%20Gen%C3%A9ricos.js.map