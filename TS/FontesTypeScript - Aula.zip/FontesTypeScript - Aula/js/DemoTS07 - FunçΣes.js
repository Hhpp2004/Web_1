"use strict";
function pegaHora() {
    return new Date().getTime();
}
function imprimeOi() {
    console.log('Oi!');
}
function multiplica(a, b) {
    return a * b;
}
console.log(pegaHora());
imprimeOi();
console.log(multiplica(2, 5));
function soma(a, b = 10, c, ...rest) {
    return a + b + (c || 0) + rest.reduce((p, c) => p + c, 0);
}
console.log(soma(2, 5));
console.log(soma(2));
console.log(soma(2, 5, 3));
console.log(soma(2, 5, 3, 1, 1, 1, 1, 1));
function divide({ dividendo, divisor }) {
    return dividendo / divisor;
}
console.log(divide({ dividendo: 10, divisor: 2 }));
console.log(divide({ divisor: 2, dividendo: 20 }));
const funcaoTrocaSinal = (value) => value * -1;
console.log(funcaoTrocaSinal(10));
console.log(funcaoTrocaSinal(-10));
//# sourceMappingURL=DemoTS07%20-%20Fun%C3%A7%C3%B5es.js.map