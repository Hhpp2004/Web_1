"use strict";
const nomes = ["Gustavo", "Fernando"];
nomes.push("Gustavo");
// Descomente a linha abaixo para testar
// nomes.push(3);
const vetorNumeros = [1, 2, 3];
vetorNumeros.push(4);
// Descomente a linha abaixo para testar
// vetorNumeros.push("abc");
let variavel1 = vetorNumeros[0];
let tupla1;
tupla1 = [5, false, 'abc'];
// Descomente a linha abaixo para testar
// tupla1 = [false, 'abc', 5];
const grafico1 = [10, 20];
grafico1[0] = 5;
grafico1[1] = 15;
const grafico2 = [20, 10];
let [x, y] = grafico2;
console.log("X da desestruturação: " + x);
console.log("Y da desestruturação: " + y);
const carro = {
    modelo: "Corolla"
};
carro.avaliacao = 9;
carro.modelo = "Onix";
// Descomente a linha abaixo para testar
// carro.modelo = 2;
const mapaNomeIdade = {
    Gustavo: 51
};
mapaNomeIdade.Fernando = 53;
// Descomente a linha abaixo para testar
// mapaNomeIdade.Aline = "Dezenove";
console.log(mapaNomeIdade);
console.log(mapaNomeIdade.Gustavo);
console.log(mapaNomeIdade.Fernando);
//# sourceMappingURL=DemoTS03%20-%20Matriz,%20tupla%20e%20objeto.js.map