"use strict";
let nome1 = "Gustavo";
let nome2 = "Gustavo";
let idade = 0;
let brasileiro = true;
// Descomentar para testar erro
// nome1 = 33;
// nome2 = 33;
// idade = "abc";
// brasileiro = 0;
let teste = true;
teste = "string";
teste = 123;
teste = false;
//# sourceMappingURL=DemoTS02%20-%20Tipo%20simples.js.map