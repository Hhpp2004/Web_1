"use strict";
let variavel2 = 'teste';
console.log(variavel2.length);
console.log(variavel2.length);
let variavel3 = 'teste';
// Descomente as linhas abaixo para testar
// console.log(((variavel3 as unknown) as number).length);
// console.log((variavel3 as number).length);
//# sourceMappingURL=DemoTS08%20-%20Casting.js.map