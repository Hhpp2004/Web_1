"use strict";
function imprimeCodigo(code) {
    console.log(`Código ${code}.`);
    // Descomente a linha abaixo para testar
    // console.log(`Código ${code.toUpperCase()}.`)
}
imprimeCodigo(404);
imprimeCodigo('404');
//# sourceMappingURL=DemoTS06%20-%20Uni%C3%A3o.js.map