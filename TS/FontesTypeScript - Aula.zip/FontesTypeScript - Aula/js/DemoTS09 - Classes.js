"use strict";
class Pessoa {
    constructor(nome) {
        this.nome = nome;
    }
    pegaNome() {
        return this.nome;
    }
}
const pessoa = new Pessoa("Gustavo");
console.log(pessoa.pegaNome());
class Poligono {
    paraString() { return `Poligono[area=${this.pegaArea()}]`; }
}
class Retangulo1 extends Poligono {
    constructor(larguraForma, alturaForma) {
        super();
        this.larguraForma = larguraForma;
        this.alturaForma = alturaForma;
    }
    pegaArea() {
        return this.larguraForma * this.alturaForma;
    }
}
class Quadrado extends Retangulo1 {
    constructor(larguraForma) {
        super(larguraForma, larguraForma);
    }
    paraString() {
        return `Quadrado[largura=${this.larguraForma}]`;
    }
}
const meuRetangulo = new Retangulo1(10, 20);
console.log(meuRetangulo.pegaArea());
console.log(meuRetangulo.paraString());
const meuQuadrado = new Quadrado(20);
console.log(meuQuadrado.pegaArea());
console.log(meuQuadrado.paraString());
//# sourceMappingURL=DemoTS09%20-%20Classes.js.map