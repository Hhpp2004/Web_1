"use strict";
let nome = "Gustavo";
console.log(nome);
console.log("Fim");
function fatorial() {
    let numero1 = 2;
    let fatorial = 1;
    let id = document.getElementById("numero1");
    let p1 = document.getElementById("p1");
    if (id)
        numero1 = parseInt(id.value);
    for (let x = numero1; x >= 1; x--) {
        fatorial = fatorial * x;
    }
    alert(fatorial);
    console.log(fatorial);
    if (p1)
        p1.innerHTML = String(fatorial);
}
//# sourceMappingURL=DemoTS01.js.map