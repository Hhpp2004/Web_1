function imprimeCodigo(code: string | number) {
    console.log(`Código ${code}.`)
    // Descomente a linha abaixo para testar
    // console.log(`Código ${code.toUpperCase()}.`)
}
imprimeCodigo(404);
imprimeCodigo('404');