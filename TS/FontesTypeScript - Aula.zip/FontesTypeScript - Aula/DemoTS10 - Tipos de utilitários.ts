interface Animal {
  nome: string;
  raca: string;
  idade?: number;
}
let meuAnimal1: Partial<Animal> = {};
meuAnimal1.nome = "Meg";
console.log(meuAnimal1);

let meuAnimal2: Required<Animal> = {
  nome: 'Pepe',
  raca: 'Yorkshire',
  // Comente a linha abaixo para testar
  idade: 7
};
console.log(meuAnimal2);

const meuAnimal3: Omit<Animal, 'raca' | 'idade'> = {
  nome: 'Duda',
  // Descomente a linha abaixo para testar
  // idade: 7
};
console.log(meuAnimal3);

const meuAnimal4: Pick<Animal, 'nome'> = {
  nome: 'Bob',
  // Descomente as linhas abaixo para testar
  // raca: 'Yorkshire',
  // idade: 7
};
console.log(meuAnimal4);

const meuAnimal5: Readonly<Animal> = {
  nome: 'Thor',
  raca: 'Rottweiler',
};
// Descomente a linha abaixo para testar
// meuAnimal5.nome = 'Gigante';
console.log(meuAnimal5);


type Basico = string | number | boolean;
let valor: Exclude<Basico, string> = true;
valor = 8;
// Descomente a linha abaixo para testar
// valor = "abc";
console.log(typeof valor);

const mapa: Record<string, number> = {
  'Alice': 21,
  'Bob': 25
};
console.log(mapa);