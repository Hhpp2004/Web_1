function pegaHora(): number {
    return new Date().getTime();
}
function imprimeOi(): void {
    console.log('Oi!');
}
function multiplica(a: number, b: number) {
    return a * b;
}
console.log(pegaHora());
imprimeOi();
console.log(multiplica(2, 5))

function soma(a: number, b: number = 10, c?: number, ...rest: number[]) {
    return a + b + (c || 0) + rest.reduce((p, c) => p + c, 0);
}
console.log(soma(2, 5))
console.log(soma(2))
console.log(soma(2, 5, 3))
console.log(soma(2, 5, 3, 1, 1, 1, 1, 1))

function divide({ dividendo, divisor }: { dividendo: number, divisor: number }) {
    return dividendo / divisor;
}
console.log(divide({ dividendo: 10, divisor: 2 }));
console.log(divide({ divisor: 2, dividendo: 20 }));

// Parâmetro nomeado com valor padrão e opcional
// function divide2({ dividendo, divisor = 5 }: { dividendo: number, divisor?: number }) {
//     return dividendo / divisor;
// }
// console.log(divide2({ dividendo: 10, divisor: 2 }));
// console.log(divide2({ dividendo: 10}));
// console.log(divide2({ divisor: 2, dividendo: 20 }));

type TipoNumero = (value: number) => number;
const funcaoTrocaSinal: TipoNumero = (value) => value * -1;
console.log(funcaoTrocaSinal(10));
console.log(funcaoTrocaSinal(-10));